from pathlib import Path

from app.ingestion.workbook import parse_workbook
from app.models import IngestionError
from app.repository import Repository


def ingest_directory(repo: Repository, root: Path, replace=False):
    """Each directory names a district; Monthly_<court ID>.xlsx names a court."""
    results = []
    for path in sorted(root.glob("*/*.xlsx")):
        if path.name.startswith("~$"):
            continue
        try:
            dataset = parse_workbook(path.read_bytes(), path.name, path.parent.name, path.stem.removeprefix("Monthly_"))
            results.append(repo.save(dataset, replace=replace))
        except (IngestionError, FileExistsError) as exc:
            results.append({"status": "error", "filename": path.name, "district": path.parent.name, "error": str(exc)})
    return results
