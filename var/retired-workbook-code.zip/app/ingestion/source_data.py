"""Import the raw CSV snapshot supplied in ``Source_Data_For_Analysis``.

The original dashboard was built around derived Excel workbooks.  This module is
deliberately small and boring: it reads the source tables, joins them by ``cino``
and stores only transparent aggregates.  No values are inferred from the old
workbook snapshot.
"""

import csv
import hashlib
from collections import defaultdict
from dataclasses import dataclass
from datetime import date
from pathlib import Path
from statistics import median


ANALYSIS_START = date(2010, 1, 1)
ANALYSIS_END = date(2026, 6, 30)
ANALYSIS_START_MONTH = "2010-01"
ANALYSIS_END_MONTH = "2026-06"

COURTS = {
    "cjm": ("CJM", "Chief Judicial Magistrate"),
    "district_judge": ("DJ", "District Judge"),
    "civil_judge_sr": ("CJ_SR", "Civil Judge (Sr. Div.)"),
    "civil_judge_jr": ("CJ_JR", "Civil Judge (Jr. Div.)"),
}


@dataclass
class SourceBundle:
    metadata: dict
    type_metrics: list[dict]
    monthly: list[dict]
    dispositions: list[dict]
    age_buckets: list[dict]
    files: list[dict]
    digest: str


def parse_date(value):
    if not value:
        return None
    try:
        return date.fromisoformat(str(value).strip())
    except ValueError:
        return None


def month_key(value):
    return value.strftime("%Y-%m")


def in_window(value):
    return value is not None and ANALYSIS_START <= value <= ANALYSIS_END


def month_grid(start=ANALYSIS_START_MONTH, end=ANALYSIS_END_MONTH):
    year, month = map(int, start.split("-"))
    result = []
    while f"{year:04d}-{month:02d}" <= end:
        result.append(f"{year:04d}-{month:02d}")
        month += 1
        if month == 13:
            year, month = year + 1, 1
    return result


def percentile(values, fraction):
    if not values:
        return None
    values = sorted(values)
    position = (len(values) - 1) * fraction
    lower, upper = int(position), min(int(position) + 1, len(values) - 1)
    return round(values[lower] + (values[upper] - values[lower]) * (position - lower), 1)


def digest_files(paths):
    digest = hashlib.sha256()
    for path in sorted(paths):
        digest.update(str(path.name).encode())
        digest.update(path.read_bytes())
    return digest.hexdigest()


def read_csv_rows(path):
    with path.open("r", newline="", encoding="utf-8-sig") as handle:
        reader = csv.DictReader(handle)
        for row in reader:
            yield row


def file_inventory(path):
    with path.open("rb") as handle:
        rows = max(0, sum(1 for _ in handle) - 1)
    return {"filename": path.name, "rows": rows, "bytes": path.stat().st_size}


def safe_case_type(code, lookup):
    code = (str(code or "").strip() or "UNKNOWN")
    found = lookup.get(code, {})
    name = (found.get("type_name") or "").strip() or ("Unclassified" if code == "UNKNOWN" else f"Type {code}")
    flag = str(found.get("type_flag") or "").strip()
    side = {"1": "Civil", "2": "Criminal"}.get(flag, "Unknown")
    return code, name, side


def blank_metrics(code, name, side):
    return {
        "type_code": code,
        "type_name": name,
        "side": side,
        "all_cases": 0,
        "pending_cases": 0,
        "disposed_cases": 0,
        "filings": 0,
        "disposals": 0,
        "first_listing_n": 0,
        "first_listing_sum": 0,
        "first_listing_values": [],
        "disposal_n": 0,
        "disposal_sum": 0,
        "disposal_values": [],
        "hearing_case_n": 0,
        "hearing_sum": 0,
        "total_hearing_days": 0,
    }


def make_bundle(root: Path, folder_name: str) -> SourceBundle:
    folder = root / folder_name
    if not folder.is_dir():
        raise FileNotFoundError(f"Missing source folder: {folder}")
    court_id, court_name = COURTS[folder_name]
    required = [
        folder / "civil_t.csv",
        folder / "civil_t_a.csv",
        folder / "daily_proc.csv",
        folder / "daily_proc_a.csv",
        folder / "case_type_t.csv",
        folder / "disp_type_t.csv",
    ]
    missing = [p.name for p in required if not p.exists()]
    if missing:
        raise FileNotFoundError(f"{folder_name}: missing {', '.join(missing)}")

    files = [file_inventory(path) for path in required]
    digest = digest_files(required)

    type_lookup = {}
    for row in read_csv_rows(folder / "case_type_t.csv"):
        code = str(row.get("case_type") or "").strip()
        if code:
            type_lookup[code] = row
    disposition_lookup = {}
    for row in read_csv_rows(folder / "disp_type_t.csv"):
        code = str(row.get("disp_type") or "").strip()
        if code:
            disposition_lookup[code] = row

    cases = {}
    duplicate_cinos = 0
    for filename, status in (("civil_t.csv", "pending"), ("civil_t_a.csv", "disposed")):
        for row in read_csv_rows(folder / filename):
            cino = str(row.get("cino") or "").strip()
            if not cino:
                continue
            if cino in cases:
                duplicate_cinos += 1
                # The archived record is the more complete representation when
                # a source export contains an overlap.
                if cases[cino]["status"] == "disposed" or status != "disposed":
                    continue
            code, name, side = safe_case_type(row.get("regcase_type"), type_lookup)
            cases[cino] = {
                "cino": cino,
                "status": status,
                "type_code": code,
                "type_name": name,
                "side": side,
                "filing": parse_date(row.get("date_of_filing")),
                "registered": parse_date(row.get("dt_regis")),
                "first_listing": parse_date(row.get("date_first_list")),
                "decision": parse_date(row.get("date_of_decision")),
                "disp_nature": str(row.get("disp_nature") or "").strip(),
            }

    hearing_dates = defaultdict(set)
    for filename in ("daily_proc.csv", "daily_proc_a.csv"):
        with (folder / filename).open("r", newline="", encoding="utf-8-sig") as handle:
            reader = csv.reader(handle)
            next(reader, None)
            for row in reader:
                if len(row) < 2:
                    continue
                cino, hearing_date = row[0].strip(), row[1].strip()
                # ISO date strings sort chronologically, avoiding millions of
                # temporary datetime objects while reading the large tables.
                if cino in cases and len(hearing_date) == 10 and "2010-01-01" <= hearing_date <= "2026-06-30":
                    hearing_dates[cino].add(hearing_date)

    metrics = {}
    monthly = defaultdict(int)
    dispositions = defaultdict(int)
    ages = defaultdict(int)
    pending_total = disposed_total = filing_total = disposal_total = hearing_total = 0

    for case in cases.values():
        key = (case["type_code"], case["type_name"], case["side"])
        if key not in metrics:
            metrics[key] = blank_metrics(*key)
        metric = metrics[key]
        metric["all_cases"] += 1
        if case["status"] == "pending":
            pending_total += 1
            metric["pending_cases"] += 1
            if case["filing"] and case["filing"] <= ANALYSIS_END:
                age_years = (ANALYSIS_END - case["filing"]).days / 365.25
                bucket = "Under 1 year" if age_years < 1 else "1–3 years" if age_years < 3 else "3–5 years" if age_years < 5 else "5+ years"
                ages[(case["type_code"], case["type_name"], case["side"], bucket)] += 1
        else:
            disposed_total += 1
            metric["disposed_cases"] += 1

        if in_window(case["filing"]):
            metric["filings"] += 1
            filing_total += 1
            monthly[("arrivals", month_key(case["filing"]), case["type_code"], case["type_name"], case["side"])] += 1

        if in_window(case["decision"]):
            metric["disposals"] += 1
            disposal_total += 1
            monthly[("disposals", month_key(case["decision"]), case["type_code"], case["type_name"], case["side"])] += 1
            disp = disposition_lookup.get(case["disp_nature"], {})
            disp_name = (disp.get("disp_name") or "Not recorded").strip()
            national_code = (disp.get("national_code") or "").strip()
            dispositions[(case["type_code"], case["type_name"], case["side"], case["disp_nature"] or "UNKNOWN", disp_name, national_code)] += 1

        if in_window(case["filing"]) and case["first_listing"] and case["first_listing"] >= case["filing"] and case["first_listing"] <= ANALYSIS_END:
            gap = (case["first_listing"] - case["filing"]).days
            metric["first_listing_n"] += 1
            metric["first_listing_sum"] += gap
            metric["first_listing_values"].append(gap)

        if case["status"] == "disposed" and in_window(case["filing"]) and in_window(case["decision"]) and case["decision"] >= case["filing"]:
            duration = (case["decision"] - case["filing"]).days
            metric["disposal_n"] += 1
            metric["disposal_sum"] += duration
            metric["disposal_values"].append(duration)

        hearing_count = len(hearing_dates.get(case["cino"], set()))
        if in_window(case["filing"]):
            metric["hearing_case_n"] += 1
            metric["hearing_sum"] += hearing_count
        metric["total_hearing_days"] += hearing_count
        hearing_total += hearing_count
        for hearing_date in hearing_dates.get(case["cino"], set()):
            monthly[("hearings", hearing_date[:7], case["type_code"], case["type_name"], case["side"])] += 1

    type_rows = []
    for metric in metrics.values():
        first_values = metric.pop("first_listing_values")
        disposal_values = metric.pop("disposal_values")
        metric["first_listing_median"] = round(median(first_values), 1) if first_values else None
        metric["first_listing_p90"] = percentile(first_values, 0.9)
        metric["disposal_median"] = round(median(disposal_values), 1) if disposal_values else None
        metric["disposal_p90"] = percentile(disposal_values, 0.9)
        metric["avg_first_listing_days"] = round(metric["first_listing_sum"] / metric["first_listing_n"], 1) if metric["first_listing_n"] else None
        metric["avg_disposal_days"] = round(metric["disposal_sum"] / metric["disposal_n"], 1) if metric["disposal_n"] else None
        metric["avg_hearings_per_case"] = round(metric["hearing_sum"] / metric["hearing_case_n"], 2) if metric["hearing_case_n"] else None
        type_rows.append(metric)

    monthly_rows = [
        {"metric": metric, "month": month, "type_code": code, "type_name": name, "side": side, "value": value}
        for (metric, month, code, name, side), value in sorted(monthly.items())
    ]
    disposition_rows = [
        {"type_code": code, "type_name": name, "side": side, "disp_code": disp_code, "disp_name": disp_name, "national_code": national_code, "value": value}
        for (code, name, side, disp_code, disp_name, national_code), value in sorted(dispositions.items(), key=lambda item: (-item[1], item[0][4]))
    ]
    age_rows = [
        {"type_code": code, "type_name": name, "side": side, "bucket": bucket, "value": value}
        for (code, name, side, bucket), value in sorted(ages.items())
    ]

    metadata = {
        "district": "Purba Medinipur",
        "court_id": court_id,
        "court_name": court_name,
        "source_folder": folder_name,
        "source_window_start": ANALYSIS_START_MONTH,
        "source_window_end": ANALYSIS_END_MONTH,
        "extracted_through": "2026-07-20",
        "analysis_cap": "2026-06-30",
        "case_count": len(cases),
        "pending_cases": pending_total,
        "disposed_cases": disposed_total,
        "filings": filing_total,
        "disposals": disposal_total,
        "hearing_days": hearing_total,
        "case_types": len(type_rows),
        "duplicate_cinos": duplicate_cinos,
        "source_note": "Raw eCourts/CIS CSV snapshot; June 2026 is the last complete analysis month.",
    }
    return SourceBundle(metadata, type_rows, monthly_rows, disposition_rows, age_rows, files, digest)


def ingest_source_directory(repo, root: Path):
    """Import all known court folders, replacing only when their digest changes."""
    results = []
    for folder_name in COURTS:
        try:
            court_id, _ = COURTS[folder_name]
            folder = root / folder_name
            required = [folder / name for name in ("civil_t.csv", "civil_t_a.csv", "daily_proc.csv", "daily_proc_a.csv", "case_type_t.csv", "disp_type_t.csv")]
            if all(path.exists() for path in required):
                digest = digest_files(required)
                if repo.source_digest("Purba Medinipur", court_id) == digest:
                    results.append({"status": "unchanged", "district": "Purba Medinipur", "court_id": court_id, "digest": digest})
                    continue
            bundle = make_bundle(root, folder_name)
            results.append(repo.save_source_bundle(bundle))
        except (FileNotFoundError, OSError, csv.Error) as exc:
            results.append({"status": "error", "court_folder": folder_name, "error": str(exc)})
    return results
