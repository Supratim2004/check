"""Read the supplied monthly-report format; no case-level data is inferred."""
import hashlib
import math
import re
from datetime import date, datetime
from io import BytesIO
from zipfile import BadZipFile, ZipFile

from openpyxl import load_workbook

from app.models import CourtDataset, IngestionError

SCHEMAS = {
    "Arrival": ["Case type", "Side", "Filings", "Mean/mo", "Median/mo", "Max/mo", "Daily rate"],
    "Gap_workdays": ["Case type", "Side", "N", "Mean", "Median", "75th", "90th", "95th"],
    "Hearings_X": ["Case type", "Side", "N", "Mean", "Median", "75th", "90th", "95th"],
    "Hearing_rate_monthly": ["Case type", "Side", "Mean", "Median", "75th", "90th", "95th"],
    "Hearing_rate_casewise": ["Case type", "Side", "N (wd)", "WD mean", "WD median", "WD 75th", "WD 90th", "WD 95th", "N (mo)", "Mo mean", "Mo median", "Mo 75th", "Mo 90th", "Mo 95th"],
    "Disposal_workdays": ["Case type", "Side", "N", "Mean", "Median", "75th", "90th", "95th"],
}
PANELS = {"arrivals": "Arrival_panel_", "hearing_rate": "HearingRate_panel_"}
MISSING = {"", "—", "–", "-", "n/a", "NA"}


def number(value, where, required=False, integer=False):
    if value is None or (isinstance(value, str) and value.strip() in MISSING):
        if required:
            raise IngestionError(f"{where}: a numeric value is required.")
        return None
    if isinstance(value, bool) or not isinstance(value, (int, float)) or not math.isfinite(value) or value < 0:
        raise IngestionError(f"{where}: expected a finite, non-negative number; got {value!r}.")
    if integer and int(value) != value:
        raise IngestionError(f"{where}: counts must be whole numbers.")
    return value


def month_key(value):
    if isinstance(value, (date, datetime)):
        return value.strftime("%Y-%m")
    value = str(value).strip()
    if not re.fullmatch(r"\d{4}-(0[1-9]|1[0-2])", value):
        raise IngestionError(f"Invalid month: {value!r}; use YYYY-MM.")
    return value


def month_grid(start, end):
    year, month = map(int, start.split("-"))
    result = []
    while f"{year:04d}-{month:02d}" <= end:
        result.append(f"{year:04d}-{month:02d}")
        month += 1
        if month == 13:
            year, month = year + 1, 1
    return result


def parse_workbook(content: bytes, filename: str, district: str, court_id: str) -> CourtDataset:
    if not filename.lower().endswith(".xlsx") or filename.startswith("~$"):
        raise IngestionError("Choose a monthly .xlsx workbook, not an Excel lock file.")
    district, court_id = district.strip(), court_id.strip()
    if not 1 <= len(district) <= 100 or not re.fullmatch(r"[A-Za-z0-9_-]{1,60}", court_id):
        raise IngestionError("Provide a district and a court ID using letters, numbers, underscores or hyphens.")
    try:
        with ZipFile(BytesIO(content)) as archive:
            if sum(i.file_size for i in archive.infolist()) > 100 * 1024 * 1024 or len(archive.infolist()) > 2000:
                raise IngestionError("Workbook exceeds the expanded size limit.")
        book = load_workbook(BytesIO(content), read_only=True, data_only=True)
    except (BadZipFile, KeyError, OSError, ValueError) as exc:
        raise IngestionError(f"Cannot read workbook: {exc}") from exc
    try:
        missing = (set(SCHEMAS) | {"Definitions"}) - set(book.sheetnames)
        if missing:
            raise IngestionError(f"Missing worksheets: {', '.join(sorted(missing))}.")
        definitions = {str(r[0]): str(r[1]) for r in book["Definitions"].iter_rows(values_only=True) if len(r) > 1 and r[0] and r[1]}
        title = str(book["Definitions"]["A1"].value or court_id)
        court_name = title.split("—")[0].strip()
        cutoff_match = re.search(r"\d{4}-\d{2}-\d{2}", definitions.get("Court cut-off", ""))
        cutoff = cutoff_match[0] if cutoff_match else None
        summaries = {}
        for name, columns in SCHEMAS.items():
            sheet = book[name]
            if sheet.max_row > 20000 or sheet.max_column > 100:
                raise IngestionError(f"{name}: worksheet is too large for the summary format.")
            rows = list(sheet.iter_rows(values_only=True))
            header = next((i for i, r in enumerate(rows[:15]) if list(r[:len(columns)]) == columns), None)
            if header is None:
                raise IngestionError(f"{name}: expected headers {', '.join(columns)}.")
            parsed, seen = [], set()
            for row_number, row in enumerate(rows[header + 1:], header + 2):
                if all(v is None for v in row):
                    continue
                case_type, side = str(row[0] or "").strip(), str(row[1] or "").strip()
                if not case_type or side not in {"Civil", "Criminal"}:
                    raise IngestionError(f"{name}, row {row_number}: invalid case type or side.")
                if case_type in seen:
                    raise IngestionError(f"{name}: duplicate case type {case_type!r}.")
                seen.add(case_type)
                record = {"Case type": case_type, "Side": side, "source_row": row_number}
                for col, val in zip(columns[2:], row[2:]):
                    record[col] = number(val, f"{name}!{col}, row {row_number}", required=col == "Filings", integer=col in {"Filings", "N", "N (wd)", "N (mo)", "Max/mo"})
                for prefix in (["WD ", "Mo "] if name == "Hearing_rate_casewise" else [""]):
                    quantiles = [record.get(prefix + key) for key in (["median", "75th", "90th", "95th"] if prefix else ["Median", "75th", "90th", "95th"])]
                    known = [v for v in quantiles if v is not None]
                    if known != sorted(known):
                        raise IngestionError(f"{name}, row {row_number}: percentiles are out of order.")
                parsed.append(record)
            summaries[name] = parsed
        arrival = {r["Case type"]: r for r in summaries["Arrival"]}
        if not arrival:
            raise IngestionError("Arrival: no case types found.")
        for name, rows in summaries.items():
            for r in rows:
                if r["Case type"] not in arrival or arrival[r["Case type"]]["Side"] != r["Side"]:
                    raise IngestionError(f"{name}: case type / side does not match Arrival.")
        panels, grids, headers = {}, [], []
        for metric, prefix in PANELS.items():
            names = [n for n in book.sheetnames if n.startswith(prefix)]
            if len(names) != 1:
                raise IngestionError(f"Expected exactly one {prefix}… worksheet.")
            sheet = book[names[0]]
            if sheet.max_row > 2401 or sheet.max_column > 501:
                raise IngestionError(f"{names[0]}: panel exceeds supported dimensions.")
            rows = list(sheet.iter_rows(values_only=True))
            cols = list(rows[0])
            if cols[0] != "Month" or len(cols) < 2 or len(set(cols)) != len(cols) or any(c not in arrival for c in cols[1:]):
                raise IngestionError(f"{names[0]}: invalid or duplicate panel headers.")
            headers.append(cols)
            months, points = [], []
            for row_num, row in enumerate(rows[1:], 2):
                if all(v is None for v in row):
                    continue
                month = month_key(row[0])
                months.append(month)
                for case_type, value in zip(cols[1:], row[1:]):
                    points.append({"month": month, "case_type": case_type, "side": arrival[case_type]["Side"], "value": number(value, f"{names[0]}, row {row_num}, {case_type}", required=True, integer=metric == "arrivals"), "source_sheet": names[0], "source_row": row_num})
            if not months or months != month_grid(months[0], months[-1]):
                raise IngestionError(f"{names[0]}: months must be unique, ordered and consecutive. Missing months are not assumed to be zero.")
            grids.append(months)
            panels[metric] = points
        if grids[0] != grids[1] or headers[0] != headers[1]:
            raise IngestionError("Arrival and hearing panels must have identical months and case types.")
        for case_type in headers[0][1:]:
            total = sum(p["value"] for p in panels["arrivals"] if p["case_type"] == case_type)
            if total != arrival[case_type]["Filings"]:
                raise IngestionError(f"{case_type}: monthly panel total {total} differs from Arrival filings {arrival[case_type]['Filings']}.")
        warnings = ["Monthly panels cover only the included case types (the supplied report uses >500 filings).", "Working-day counts and individual case records are not supplied; calendar, backlog and clearance cannot be reconstructed.", "Summary distributions use their original full-window cohorts and do not change with the chart date range.", "The workbook cut-off note mentions hearing rate broadly; the PDF explicitly uses the full window for calendar hearing throughput. Source values are preserved."]
        if not cutoff:
            warnings.append("Listing reliability cut-off is not specified in Definitions.")
        return CourtDataset(district, court_id.upper(), court_name, filename, hashlib.sha256(content).hexdigest(), grids[0][0], grids[0][-1], len(grids[0]), cutoff, definitions, summaries, panels, warnings)
    finally:
        book.close()
