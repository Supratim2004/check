from dataclasses import dataclass, field
from typing import Any


@dataclass
class CourtDataset:
    district: str
    court_id: str
    court_name: str
    filename: str
    digest: str
    start: str
    end: str
    months: int
    cutoff: str | None
    definitions: dict[str, str]
    summaries: dict[str, list[dict[str, Any]]]
    panels: dict[str, list[dict[str, Any]]]
    warnings: list[str] = field(default_factory=list)


class IngestionError(ValueError):
    """An invalid workbook, with a user-readable explanation."""
