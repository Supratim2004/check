"""Calculations on normalized records, independent of Excel and HTTP."""
from collections import defaultdict
from statistics import mean, median

from app.ingestion.workbook import month_grid


def weighted_mean(rows, value="Mean", weight="N"):
    eligible = [r for r in rows if r.get(value) is not None and r.get(weight) is not None and r[weight] > 0]
    n = sum(r[weight] for r in eligible)
    return {"value": round(sum(r[value] * r[weight] for r in eligible) / n, 3) if n else None, "n": n}


def trend(values, window=12):
    """Trailing full-window mean and OLS fitted line; never forecast."""
    moving = [round(mean(values[i - window + 1:i + 1]), 4) if i >= window - 1 and all(v is not None for v in values[i - window + 1:i + 1]) else None for i in range(len(values))]
    valid = [(i, y) for i, y in enumerate(values) if y is not None]
    if len(valid) < 2:
        return moving, [None] * len(values)
    x_mean, y_mean = mean(x for x, _ in valid), mean(y for _, y in valid)
    slope = sum((x - x_mean) * (y - y_mean) for x, y in valid) / sum((x - x_mean) ** 2 for x, _ in valid)
    return moving, [round(y_mean + slope * (i - x_mean), 4) for i in range(len(values))]


def build_timeseries(points, metric, start, end):
    groups = defaultdict(dict)
    for p in points:
        key = (p["court_id"], p["case_type"])
        groups[key][p["month"]] = p["value"]
    months = month_grid(start, end)
    series = []
    for (court_id, case_type), mapping in groups.items():
        values = [mapping.get(m) for m in months]
        moving, fitted = trend(values)
        series.append({"court_id": court_id, "case_type": case_type, "values": values, "moving_average": moving, "linear_trend": fitted})
    # Only arrivals are additive across courts. Hearing rates retain each court's denominator.
    aggregate = None
    if metric == "arrivals" and series:
        values = [sum(s["values"][i] for s in series) if all(s["values"][i] is not None for s in series) else None for i in range(len(months))]
        moving, fitted = trend(values)
        aggregate = {"court_id": "Selected courts", "case_type": "Panel case types", "values": values, "moving_average": moving, "linear_trend": fitted}
    return {"months": months, "series": series, "aggregate": aggregate, "metric": metric, "units": "filings / month" if metric == "arrivals" else "hearings / court working day", "scope": "Only case types included in the source monthly panels.", "trend_method": "Trailing 12-month average (12 observations required); linear least-squares fit over the selected range."}


def overview(repo, district, court_id=None, side=None, case_type=None):
    filters = dict(court_id=court_id, side=side, case_type=case_type)
    arrivals = repo.rows("summary_rows", district, "Arrival", **filters)
    disposal = repo.rows("summary_rows", district, "Disposal_workdays", **filters)
    gap = repo.rows("summary_rows", district, "Gap_workdays", **filters)
    hearings = repo.rows("summary_rows", district, "Hearings_X", **filters)
    panel = repo.rows("monthly_points", district, "arrivals", **filters)
    panel_filings = sum(p["value"] for p in panel)
    filings = sum(r["Filings"] for r in arrivals)
    catalog = [c for c in repo.catalog() if c["district"].casefold() == district.casefold() and (not court_id or c["court_id"] == court_id)]
    comparisons = []
    for court in catalog:
        rows = [r for r in arrivals if r["court_id"] == court["court_id"]]
        if not rows:
            continue
        comparisons.append({"court_id": court["court_id"], "court_name": court["court_name"], "filings": sum(r["Filings"] for r in rows), "case_types": len(rows), "mean_disposal": weighted_mean([r for r in disposal if r["court_id"] == court["court_id"]]), "mean_gap": weighted_mean([r for r in gap if r["court_id"] == court["court_id"]]), "mean_hearings": weighted_mean([r for r in hearings if r["court_id"] == court["court_id"]]), "start": court["start"], "end": court["end"]})
    return {"filings": filings, "case_types": len({r["Case type"] for r in arrivals}), "court_case_types": len(arrivals), "courts": len(comparisons), "disposal": weighted_mean(disposal), "gap": weighted_mean(gap), "hearings": weighted_mean(hearings), "panel_filings": panel_filings, "panel_coverage_pct": round(panel_filings / filings * 100, 2) if filings else None, "by_side": {s: sum(r["Filings"] for r in arrivals if r["Side"] == s) for s in ("Civil", "Criminal")}, "top_cases": sorted(arrivals, key=lambda r: r["Filings"], reverse=True), "comparisons": comparisons, "scope": "Full source reporting window. Duration and hearing means are approximate N-weighted means of rounded source statistics. Quantiles are never pooled.", "periods_match": len({(c["start"], c["end"]) for c in catalog}) <= 1}
