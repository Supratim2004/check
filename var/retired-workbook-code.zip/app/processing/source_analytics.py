"""Analytics over the raw-source aggregates."""

from collections import defaultdict

from app.ingestion.source_data import ANALYSIS_END_MONTH, ANALYSIS_START_MONTH, month_grid


def selected_catalog(repository, district, court_id=None):
    return [c for c in repository.source_catalog() if c["district"].casefold() == district.casefold() and (not court_id or c["court_id"] == court_id)]


def _weighted(rows, sum_key, count_key):
    count = sum((row.get(count_key) or 0) for row in rows)
    total = sum((row.get(sum_key) or 0) for row in rows)
    return {"value": round(total / count, 1) if count else None, "n": count}


def _empty_series(months):
    return {month: 0 for month in months}


def overview(repository, district, court_id=None, side=None, type_code=None):
    courts = selected_catalog(repository, district, court_id)
    rows = repository.source_type_metrics(district, court_id, side, type_code)
    filings = sum(row["filings"] for row in rows)
    disposals = sum(row["disposals"] for row in rows)
    pending = sum(row["pending_cases"] for row in rows)
    disposed = sum(row["disposed_cases"] for row in rows)
    all_cases = sum(row["all_cases"] for row in rows)
    hearings = sum(row["hearing_sum"] for row in rows)
    hearing_cases = sum(row["hearing_case_n"] for row in rows)
    by_side = defaultdict(lambda: {"filings": 0, "pending": 0, "disposed": 0})
    for row in rows:
        by_side[row["side"]]["filings"] += row["filings"]
        by_side[row["side"]]["pending"] += row["pending_cases"]
        by_side[row["side"]]["disposed"] += row["disposed_cases"]
    top_types = sorted(rows, key=lambda row: (row["filings"], row["all_cases"]), reverse=True)[:8]
    return {
        "district": district,
        "window": {"start": ANALYSIS_START_MONTH, "end": ANALYSIS_END_MONTH, "label": "Jan 2010 – Jun 2026"},
        "courts": courts,
        "selected_courts": len(courts),
        "totals": {
            "filings": filings,
            "disposals": disposals,
            "pending": pending,
            "disposed": disposed,
            "all_cases": all_cases,
            "hearing_days": sum(row["total_hearing_days"] for row in rows),
            "case_types": len(rows),
        },
        "avg_disposal": _weighted(rows, "disposal_sum", "disposal_n"),
        "avg_first_listing": _weighted(rows, "first_listing_sum", "first_listing_n"),
        "avg_hearings": {"value": round(hearings / hearing_cases, 2) if hearing_cases else None, "n": hearing_cases},
        "by_side": dict(by_side),
        "top_types": top_types,
        "coverage": {
            "source_case_records": all_cases,
            "case_type_rows": len(rows),
            "analysis_note": "Counts use the raw case tables; July 2026 records are outside the complete-month analysis window.",
        },
    }


def timeseries(repository, district, court_id=None, side=None, type_code=None, start=ANALYSIS_START_MONTH, end=ANALYSIS_END_MONTH):
    months = month_grid(start, end)
    points = repository.source_monthly(district, court_id=court_id, side=side, type_code=type_code, start=start, end=end)
    aggregate = {metric: _empty_series(months) for metric in ("arrivals", "disposals", "hearings")}
    by_court = defaultdict(lambda: {metric: _empty_series(months) for metric in ("arrivals", "disposals", "hearings")})
    court_names = {court["court_id"]: court["court_name"] for court in selected_catalog(repository, district, court_id)}
    for point in points:
        metric = point["metric"]
        if metric in aggregate:
            aggregate[metric][point["month"]] += point["value"]
            by_court[point["court_id"]][metric][point["month"]] += point["value"]
    return {
        "months": months,
        "aggregate": [{"month": month, **{metric: aggregate[metric][month] for metric in aggregate}} for month in months],
        "courts": [{"court_id": court_id, "court_name": court_names.get(court_id, court_id), "values": [{"month": month, **{metric: values[metric][month] for metric in values}} for month in months]} for court_id, values in by_court.items()],
        "window": {"start": start, "end": end},
        "note": "Monthly activity is counted from filing dates, decision dates, and distinct hearing dates in the raw tables.",
    }


def case_types(repository, district, court_id=None, side=None, type_code=None):
    rows = repository.source_type_metrics(district, court_id, side, type_code)
    rows.sort(key=lambda row: (row["filings"], row["all_cases"], row["type_name"]), reverse=True)
    return rows


def dispositions(repository, district, court_id=None, side=None, type_code=None):
    rows = repository.source_dispositions(district, court_id, side, type_code)
    grouped = defaultdict(lambda: {"disp_name": "", "national_code": "", "value": 0})
    for row in rows:
        key = (row["disp_code"], row["disp_name"], row["national_code"])
        grouped[key]["disp_name"] = row["disp_name"]
        grouped[key]["national_code"] = row["national_code"]
        grouped[key]["value"] += row["value"]
    return [{"disp_code": code, **value} for (code, _, _), value in sorted(grouped.items(), key=lambda item: item[1]["value"], reverse=True)]


def aging(repository, district, court_id=None, side=None, type_code=None):
    rows = repository.source_age_buckets(district, court_id, side, type_code)
    order = {"Under 1 year": 0, "1–3 years": 1, "3–5 years": 2, "5+ years": 3}
    totals = defaultdict(int)
    for row in rows:
        totals[row["bucket"]] += row["value"]
    return [{"bucket": bucket, "value": totals[bucket]} for bucket in sorted(totals, key=lambda item: order.get(item, 9))]


def dashboard(repository, district, court_id=None, side=None, type_code=None, start=ANALYSIS_START_MONTH, end=ANALYSIS_END_MONTH):
    return {
        "overview": overview(repository, district, court_id, side, type_code),
        "timeseries": timeseries(repository, district, court_id, side, type_code, start, end),
        "case_types": case_types(repository, district, court_id, side, type_code),
        "dispositions": dispositions(repository, district, court_id, side, type_code),
        "aging": aging(repository, district, court_id, side, type_code),
    }
